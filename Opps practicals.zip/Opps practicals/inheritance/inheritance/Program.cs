﻿using System;

namespace inheritance
{
    class Parent
    {
        public void show() 
        {
            Console.WriteLine("\nParent Class Called....");

        }
       
    }
    class Chaild:Parent
    {
        public void disp()
        {
            Console.WriteLine("Chaild Class Called....");
        }
    }

    class subchaild : Chaild
    {
        public void demo()
        {
            Console.WriteLine("Subchaild Class Called....\n");
        }
    }

    //---------------------- Multiple Inheritance With Interface----------------------

   interface I1
    {
        void interfaceDemo();
       
    }
    interface I2
    {
        void interfaceDemo();
    }

    class Chaildinterface : I1, I2
    {
       

        public void Normalcls()
        {
            Console.WriteLine("Normal class Called....");
        }
        void I1.interfaceDemo()
        {
            Console.WriteLine("\nInterface 1 Called....");
        }

        void I2.interfaceDemo()
        {
            Console.WriteLine("Interface 2 Called....");
        }

    }

    class Program { 
        static void Main(string[] args)
        {
            Console.WriteLine("________________________Multilevel Inheritance______________________________");

            subchaild sc=new subchaild();
            sc.show();
            sc.disp();
            sc.demo();

            Console.WriteLine("_______________________Multiple Inheritance With Interface___________________________");

            I1 i1=new Chaildinterface();
            i1.interfaceDemo();

            I2 i2=new Chaildinterface();
            i2.interfaceDemo();

            Chaildinterface ci=new Chaildinterface();
            ci.Normalcls();



            Console.ReadKey();
        }
 }
}

