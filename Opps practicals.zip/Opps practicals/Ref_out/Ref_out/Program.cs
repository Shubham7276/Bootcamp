﻿using System;

namespace Ref_out
{

    
    class Program
    {
        static void Example1(ref int a)
        {
            a = 10;
        }

        static void Example2(out int b)
        {
            b = 12;
        }

        static void Main(string[] args)
        {
            int val1 = 10;
            int val2 = 20;
            Program.Example1(ref val1);
            Console.WriteLine(val1);

            Program.Example2(out val2);
            Console.WriteLine(val2);
        }
    }
}
