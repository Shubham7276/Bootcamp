﻿using System;

namespace Abstraction
{
    abstract class basecls
    {
        public abstract void show();

        public void disp()
        {
            Console.WriteLine("Normal Class Called....");
        }
    }
    class derived : basecls
    {
        public override void show()
        {
            Console.WriteLine("Abstarct Class Called....");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
           derived  dc= new derived();
            dc.show();
            dc.disp();

            Console.ReadKey();
        }
    }
}
