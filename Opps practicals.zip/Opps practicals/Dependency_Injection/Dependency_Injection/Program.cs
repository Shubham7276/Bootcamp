﻿using System;

namespace Dependency_Injection
{   
    interface I1
    {
        void disp();
    }
    
  
    class Chaild : I1
    {
        void I1.disp()
        {
            Console.WriteLine("First Interface Called");
        }
      
    }
    class Chaild2 : I1
    {
        void I1.disp()
        {
            Console.WriteLine("Second Interface Called");
        }
    }

    //__________________________Injuction with Property__________________


    interface I3
    {
        void proparty(string massage);
    }
    class Chaild3 : I3
    {
        public void proparty(string massage)
        {
            Console.WriteLine(massage);
        }
    }

    class propertyIJ
    {
        private I3 _i;
        public void demoprop(I3 _i,string message)
        {
            this._i = _i;
            _i.proparty(message);
        }
    }


    //________________________________Comstructor Injuction__________________________

    class ConstractorIJ
    {
        private I1 _i;
        public ConstractorIJ(I1 _i)
        {
            this._i = _i;
        }

        public void demo()
        {
            _i.disp();
        }
    }
    //__________________________Injuction with Method__________________
    class method
    {
        private I1 _i;
        public void print(I1 _i)
        {
            this._i = _i;
            _i.disp();
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            ConstractorIJ CJ = null;
            Console.WriteLine("________________________________Comstructor Injuction__________________________\n");
            CJ = new ConstractorIJ(new Chaild());
            CJ.demo();

            CJ = new ConstractorIJ(new Chaild2());
            CJ.demo();

            Console.WriteLine("\n__________________________Injuction with Method__________________\n");

            method m = new method();
            m.print(new Chaild());
            m.print(new Chaild2());

            Console.WriteLine("\n__________________________Injuction with Property__________________\n");

            propertyIJ pIJ=new propertyIJ();
            pIJ.demoprop(new Chaild3(), "Message - Property Value Passed.");

            Console.ReadKey();
        }
    }
}
