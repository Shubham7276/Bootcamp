﻿using System;

namespace polymorphism
{
    class addition
    {
        public void add(int a)
        {
            Console.WriteLine(a);
        }
        public void add(int a, int b)
        {
            Console.WriteLine(a + b);
        }
        public void add(int a, int b, int c)
        {
            Console.WriteLine(a + b + c);
        }
    }

    abstract class Multiplication
    {
        abstract public void Mult();
    }

    class Multiplication2 : Multiplication
    {
        public override void Mult()
        {
            int a = 10;
            int b = 20;
            int c = a * b;
            Console.WriteLine("Method Overriding");
            Console.WriteLine("Multiplication Two values:-" + c);
        }
    }



    class Program
    {
        static void Main(string[] args)
        {

            addition ad = new addition();

            Console.WriteLine("_______________________________Method OverLoding____________________________\n");
            ad.add(10);
            ad.add(10,20);
            ad.add(10,20,30);

            Console.WriteLine("\n_______________________________Method OverLoding____________________________\n");

            Multiplication2 M=new Multiplication2();
            M.Mult();

            Console.ReadKey();
        }
    }
}
