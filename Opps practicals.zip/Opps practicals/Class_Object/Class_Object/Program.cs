﻿using System;

namespace Class_Object
{
    class basecls
    {
        public void show()
        {
            Console.WriteLine("Called Base Class.....");
        }
    }
    static class basecls2
    {
        static public void disp()
        {
            Console.WriteLine("Called static class....");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            basecls bc = new basecls();
            bc.show();

            basecls2.disp();

            Console.ReadKey();  
        }
    }
}
