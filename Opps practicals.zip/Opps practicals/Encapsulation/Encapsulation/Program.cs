﻿using System;

namespace Encapsulation
{
    class student
    {
        private string name;
        private int age;
        public void getname()
        {
            Console.WriteLine("Name Of Student:- "+name);
            Console.WriteLine("Age Of Student:- " + age);
        }

        public void setname(string name, int age)
        {
            this.name = name;
            this.age = age;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            student s1 = new student();
            s1.setname("Khushal",25);

            s1.getname();
            
        }
    }
}
